/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.motorph_1;

/**
 *
 * @author AMD PC
 */
import java.sql.*;
import javax.swing.*;
import java.sql.Connection;

public class DBConn {
    Connection conn =null;
    public static Connection javaconn(){
        
        try{
            Class.forName("org.postgresql.Driver");
            Connection conn =DriverManager.getConnection("jdbc:postgresql://localhost:5432/empdata", "admin", "admin101");
           
      
            return conn;
           
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
        
    }
}
