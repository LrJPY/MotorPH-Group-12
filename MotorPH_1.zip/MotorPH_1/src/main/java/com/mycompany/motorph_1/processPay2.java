

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.motorph_1;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author AMD PC
 */
public class processPay2 extends javax.swing.JFrame {

    /**
     * Creates new form processPay
     */
    public processPay2() {
        initComponents();
        
        jTable1.setRowHeight(25);
        jTable1.setShowGrid(true);
        jTable1.setGridColor(Color.white);
        jTable1.setSelectionBackground(Color.black);
        showData("", "");
    }

    public static Connection getConnection()
    {
        Connection conn = null;
        
         try {

            Class.forName("org.postgresql.Driver");
             conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/empdata", "admin", "admin101");
        } catch (Exception ex) {

             System.out.println(ex.getMessage());

        }
        return conn;
    }
    
    public void showData(String d1, String d2)
    {
        Connection conn = getConnection();
        PreparedStatement st;
        ResultSet rs;
        
        try{
            
            if(d1.equals("") || d2.equals(""))
            {
                st = conn.prepareStatement("SELECT * FROM login.payroll_data");
            }else{
                st = conn.prepareStatement("SELECT * FROM login.payroll_data WHERE ddate >= TO_DATE(?, 'YYYY-MM-DD') AND ddate <= TO_DATE(?, 'YYYY-MM-DD')");
                st.setString(1, d1);
                st.setString(2, d2);
            }
            
            rs = st.executeQuery();
            DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
            model.setRowCount(0);
            while(rs.next()){
                int row1 = rs.getInt(2)/2;
                int row2 = rs.getInt(3)/2;
                int row3 = rs.getInt(4)/2;
                int row4 = rs.getInt(5)/2;
                int sum = row2+row3+row4;
                int hourlyrate = rs.getInt(2)*12/365;
                int sum1 = sum + row1;
                
                //Philhealth
                double value2 = row1 * 0.05/2;
                //Pagibig
                double value3 = 0;
                if (sum1 >= 0 && sum1 <= 1500){
                    value3 = sum1 * 0.01;  
                }else if (sum1 >= 1501 && sum1 <= 9999.99){
                    value3 = sum1 * 0.02;
                }else if(sum1 >= 10000 && sum1 <=100000){
                     value3 = 200;
                }
                //SSS
                double value = 0;
                if (sum1 >= 29750 && sum1 <= 100000){
                    value = 1350;
                }else if (sum1 >= 29250 && sum1 <= 29749.99){
                    value = 1327.50;
                }else if (sum1 >= 28750 && sum1 <=29249.99){
                    value = 1305;
                }else if (sum1 >= 28250 && sum1 <=28749.99){
                    value = 1282.50; 
                }else if (sum1 >= 27750 && sum1 <=28249.99){
                    value = 1260;
                }else if (sum1 >= 27250 && sum1 <=27749.99){
                    value = 1237.50;
                }else if (sum1 >= 26750 && sum1 <=27249.99){
                    value = 1215;
                }else if (sum1 >= 26250 && sum1 <=26749.99){
                    value = 1192.5; 
                }else if (sum1 >= 25750 && sum1 <=26249.99){
                    value = 1170;
                }else if (sum1 >= 25250 && sum1 <=25749.99){
                    value = 1147.50;
                }else if (sum1 >= 24750 && sum1 <=25249.99){
                    value = 1125;
                }else if (sum1 >= 24250 && sum1 <=24749.99){
                    value = 1102.50; 
                }else if (sum1 >= 23750 && sum1 <=24249.99){
                    value = 1080;
                }else if (sum1 >= 23250 && sum1 <=23749.99){
                    value = 1057.50;
                }else if (sum1 >= 22750 && sum1 <=23249.99){
                    value = 1035;
                }else if (sum1 >= 22250 && sum1 <=22749.99){
                    value = 1012.50; 
                }else if (sum1 >= 21750 && sum1 <=22249.99){
                    value = 990;
                }else if (sum1 >= 21250 && sum1 <=21749.99){
                    value = 967.50;
                }else if (sum1 >= 20750 && sum1 <=21249.99){
                    value = 945;
                }else if (sum1 >= 20250 && sum1 <=20749.99){
                    value = 922.50; 
                }else if (sum1 >= 19750 && sum1 <=20249.99){
                    value = 900;
                }else if (sum1 >= 19250 && sum1 <=19749.99){
                    value = 877.50;
                }else if (sum1 >= 18750 && sum1 <=19249.99){
                    value = 855;
                }else if (sum1 >= 18250 && sum1 <=18749.99){
                    value = 832.50; 
                }else if (sum1 >= 17750 && sum1 <=18249.99){
                    value = 810;
                }else if (sum1 >= 17250 && sum1 <=17749.99){
                    value = 787.50;
                }else if (sum1 >= 16750 && sum1 <=17249.99){
                    value = 765;
                }else if (sum1 >= 16250 && sum1 <=16749.99){
                    value = 742.50; 
                }else if (sum1 >= 15750 && sum1 <=16249.99){
                    value = 720;
                }else if (sum1 >= 15250 && sum1 <=15749.99){
                    value = 697.50;
                }else if (sum1 >= 14750 && sum1 <=15249.99){
                    value = 675;
                }else if (sum1 >= 14250 && sum1 <=14749.99){
                    value = 652.50; 
                }else if (sum1 >= 13750 && sum1 <=14249.99){
                    value = 630;
                }else if (sum1 >= 13250 && sum1 <=13749.99){
                    value = 607.50;
                }else if (sum1 >= 12750 && sum1 <=13249.99){
                    value = 585;
                }else if (sum1 >= 12250 && sum1 <=12749.99){
                    value = 562.50; 
                }else if (sum1 >= 11750 && sum1 <=12249.99){
                    value = 540;
                }else if (sum1 >= 11250 && sum1 <=11749.99){
                    value = 517.50;
           
        
                }
                
                //tax
                double value4 = sum1 - row4;
                double value5 = 0;
                if (value4 >= 0 && value4 <=10416){
                    value5 = 0;
                }else if (value4 >= 10417 && value4 <= 16666){
                    double diff = value4 - 10417;
                    value5 = diff *0.15;
                }else if (value4>= 16667 && value4<= 33332){
                    double diff = value4 - 16667;
                    double sumtax = diff *0.20;
                    value5 = sumtax + 937.50;
                }else if (value4>= 33333 && value4 <= 83332){
                double diff = value4 - 33333;
                double sumtax = diff *0.25;
                value5 = sumtax + 4270.70;
                }else if (value4>= 83333 && value4 <= 333332){
                double diff = value4 - 83333;
                double sumtax = diff *0.30;
                value5 = sumtax + 16770.70;
                }else if (value4>= 333333 && value4 <= 9999999){
                 double diff = value4 - 333333;
                double sumtax = diff *0.35;
                value5 = sumtax + 91770.70;
    
                }
                
                //net pay
                double value6 = sum1 - value5 - value - value2 - value3;
            Object[] row;
            
            
            
                row = new Object[14];
                row[0] = rs.getInt(1);
                row[1] = row1;
                row[2] = row2;
                row[3] = row3;
                row[4] = row4;
                row[5] = rs.getDate(6);
                row[6] = sum;
                row[7] = hourlyrate;
                row[8] = sum1;
                row[9] = value;
                row[10] = value2;
                row[11] = value3;
                row[12] = value5;
                row[13] = value6;
                
                
                model.addRow(row);
            }
            
        }catch(Exception e){

            System.out.println(e.getMessage());

        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Employee No.", "Basic Salary - Semi", "Clothing", "Mobile", "Rice", "Period", "Total Allowances", "Daily Rate", "Gross Pay", "SSS", "Philhealth", "PAGIBIG", "Tax", "Net Pay"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Payroll Calculation");

        jButton2.setText("View Payslip");

        jLabel2.setText("Start Date");

        jLabel3.setText("End Date");

        jLabel4.setText("Employee No.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel1))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(27, 27, 27)
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(39, 39, 39)
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jButton1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4)
                            .addGap(31, 31, 31)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(28, 28, 28)
                            .addComponent(jButton2))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1095, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton1)
                                    .addComponent(jButton2)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addComponent(jDateChooser2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
            
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            
            String date1 = df.format(jDateChooser1.getDate());
            String date2 = df.format(jDateChooser2.getDate());    
            System.out.println("date1: "+ date1);
            System.out.println("date2: "+ date2);
        try{
            Connection conn = getConnection();
            PreparedStatement st;
            ResultSet rs;
            st = conn.prepareStatement("SELECT * FROM login.payroll_data WHERE ddate >= TO_DATE(?, 'YYYY-MM-DD') AND ddate <= TO_DATE(?, 'YYYY-MM-DD')");
            st.setString(1, date1);
            st.setString(2, date2);
            
            
            rs = st.executeQuery();
            jTable1.setModel(new DefaultTableModel(null, new Object[]{"Employee No","Basic Salary","Clothing Allowance","Mobile Allowance","Rice Allowance","Period","Total Allowance","Daily Rate","Gross Pay","SSS","Philhealth","PAGIBIG","Tax","Net Pay"}));
           
            showData(date1, date2);
            
        }catch(Exception e){
            e.printStackTrace();
        }
    
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(processPay2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(processPay2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(processPay2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(processPay2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new processPay2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
