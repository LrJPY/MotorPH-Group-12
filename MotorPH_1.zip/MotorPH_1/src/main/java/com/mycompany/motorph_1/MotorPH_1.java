/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.motorph_1;

/**
 *
 * @author AMD PC
 */
public class MotorPH_1 {

    public static void main(String[] args) {
      
    }
}
